// Rakel nyoba Challenge1_1
let count = 1;

while (count <= 120) {
  console.log(`Hey kawan, saya orang ke- ${count}`);
  count++;
}