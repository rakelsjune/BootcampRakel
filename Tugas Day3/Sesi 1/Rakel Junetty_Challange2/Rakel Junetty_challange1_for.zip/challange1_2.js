// Rakel nyoba Challenge1_2
for (let count = 1; count <= 120; count++) {
    console.log(`Hey Kawan, saya orang ke- ${count}`);
  }